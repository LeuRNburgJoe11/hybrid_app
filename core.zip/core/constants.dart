class AppConstants {
  AppConstants._();

  // Your live cloud REST API control plane URL
  static const String baseUrl = 'https://webrtc-backend-wtfl.onrender.com';

  // Your live cloud Socket.io WebSocket URL
  static const String signalingUrl = 'https://webrtc-backend-wtfl.onrender.com/socket.io';
}